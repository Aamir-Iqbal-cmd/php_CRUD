<?php

include('../includes/config.php');


if (isset($_POST['cat_id'])) {
    $category_id = $_POST['cat_id'];

    $query = "SELECT * FROM subcategories WHERE category_id = $category_id";
    $result = mysqli_query($conn, $query);

    $subcategories = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $subcategories[] = array(
            'id' => $row['id'],
            'subcategory_name' => $row['subcategory_name']
        );
    }

    echo json_encode($subcategories);
}

