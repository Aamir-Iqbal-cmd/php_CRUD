<?php

session_start();

include '../includes/config.php';

// ============================================================ add category ===============================================================

if (isset($_POST['add_category'])) {

    $category_name = mysqli_real_escape_string($conn, $_POST['category_name']);
    $category_desc = mysqli_real_escape_string($conn, $_POST['category_desc']);


    if (!empty($category_name)) {

        $check_query = "SELECT * FROM categories WHERE category_name = '$category_name'";
        $result = mysqli_query($conn, $check_query);

        if (mysqli_num_rows($result) > 0) {

            $_SESSION["error"] = "Category '$category_name' already exists!";
            header('location:../add_category.php');
        } else {

            $sql = "INSERT INTO categories (category_name, category_desc) VALUES ('$category_name', '$category_desc')";

            if (mysqli_query($conn, $sql)) {

                $_SESSION["success"] = "New category added successfully!";
                header('location:../add_category.php');
            } else {

                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
        }
    } else {

        $_SESSION["error"] = "Please fill out all fields!";
        header('location:../add_category.php');
    }
}
//  ========================================================== Update Category ===============================================================

if (isset($_POST['update_category'])) {
   
    $category_id = $_POST['category_id'];  
    $category_name = $_POST['category_name'];
    $category_desc = $_POST['category_desc'];


    if (!empty($category_name)) {
     
        $update_query = "UPDATE categories SET category_name='$category_name', category_desc='$category_desc' WHERE id = '$category_id'";
        
        if (mysqli_query($conn, $update_query)) {
            $_SESSION['success'] = "Category updated successfully!";
        } else {
            $_SESSION['error'] = "Failed to update category.";
        }
    } else {
        $_SESSION['error'] = "Please fill out all required fields.";
    }

    header('Location: ../edit_category.php?cat_id=' . $category_id);

}

// ============================================================ delete catogery ===============================================================

if(isset($_GET['delete_cat_id'])){
    $delete_cat = mysqli_query($conn, "DELETE FROM categories WHERE id = '".$_GET['delete_cat_id']."'");
    if($delete_cat){
        $delete_subcat = mysqli_query($conn, "DELETE FROM subcategories WHERE category_id = '".$_GET['delete_cat_id']."'");
        if($delete_subcat){
            $delete_product = mysqli_query($conn, "DELETE FROM products WHERE cat_id = '".$_GET['delete_cat_id']."'");
            if($delete_product){
                $_SESSION['success'] = "Category Delete successfully!";
                header('Location: ../categories_list.php');

            }
        }
    }

}


// ============================================================ add Subcategory ===============================================================

if (isset($_POST['add_subcategory'])) {

    $subcategory_name = mysqli_real_escape_string($conn, $_POST['category_name']);
    $category_id = mysqli_real_escape_string($conn, $_POST['cat_id']);
    $subcategory_desc = mysqli_real_escape_string($conn, $_POST['category_desc']);


    if (!empty($subcategory_name) && !empty($category_id)) {

        $check_query = "SELECT * FROM subcategories WHERE subcategory_name = '$subcategory_name'";
        $result = mysqli_query($conn, $check_query);

        if (mysqli_num_rows($result) > 0) {

            $_SESSION["error"] = "Subcategory '$subcategory_name' already exists!";
            header('location:../add_category.php');
        } else {

            $sql = "INSERT INTO subcategories (subcategory_name, category_id, subcategory_desc) 
                VALUES ('$subcategory_name', '$category_id', '$subcategory_desc')";


            if (mysqli_query($conn, $sql)) {
                $_SESSION["success"] = "New Subcategory added successfully!";
                header('location:../add_subcategory.php');
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
        }
    } else {
        echo "Please fill out all required fields!";
    }
}

// ====================================================== Update SubCategory ====================================================================

if (isset($_POST['update_subcategory'])) {
    
    $subcategory_id = $_POST['subcategory_id'];  
    $subcategory_name = $_POST['category_name'];
    $category_id = $_POST['cat_id'];
    $subcategory_desc = $_POST['category_desc'];

    
    if (!empty($subcategory_name) && !empty($category_id)) {
       
        $update_query = "UPDATE subcategories SET subcategory_name='$subcategory_name', subcategory_desc='$subcategory_desc', category_id='$category_id' WHERE id = '$subcategory_id'";
        
        if (mysqli_query($conn, $update_query)) {
            $_SESSION['success'] = "Subcategory updated successfully!";
        } else {
            $_SESSION['error'] = "Failed to update subcategory.";
        }
    } else {
        $_SESSION['error'] = "Please fill out all required fields.";
    }

    header('Location: ../edit_subcategory.php?subcat_id=' . $subcategory_id);

}

// ============================================================ delete Subcatogery ===============================================================

if(isset($_GET['delete_subcat_id'])){
   
        $delete_subcat = mysqli_query($conn, "DELETE FROM subcategories WHERE id = '".$_GET['delete_subcat_id']."'");
        if($delete_subcat){
            $delete_product = mysqli_query($conn, "DELETE FROM products WHERE subcat_id = '".$_GET['delete_subcat_id']."'");
            if($delete_product){
                $_SESSION['success'] = "Subcategory Delete successfully!";
                header('Location: ../subcategories_list.php');

            }
        }

}


// ============================================================ add product ======================================================================

if (isset($_POST['add_product'])) {

    $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
    $product_price = mysqli_real_escape_string($conn, $_POST['product_price']);
    $cat_id = mysqli_real_escape_string($conn, $_POST['cat_id']);
    $subcat_id = mysqli_real_escape_string($conn, $_POST['subcat_id']);
    $quantity = mysqli_real_escape_string($conn, $_POST['quantity']);
    $product_desc = mysqli_real_escape_string($conn, $_POST['product_desc']);


    $image_name = $_FILES['pro_image']['name'];
    $image_temp = $_FILES['pro_image']['tmp_name'];
    $image_folder = '../uploads/' . $image_name;

    if (!empty($product_name) && !empty($cat_id) && !empty($subcat_id)) {

        $check_query = "SELECT * FROM products WHERE product_name = '$product_name' AND cat_id = '$cat_id' AND subcat_id = '$subcat_id'";
        $result = mysqli_query($conn, $check_query);

        if (mysqli_num_rows($result) > 0) {

            $_SESSION["error"] = "Products '$product_name' already exists!";
            header('location:../add_product.php');
        } else {

            if (move_uploaded_file($image_temp, $image_folder)) {

                $query = "INSERT INTO products (product_name, product_price, cat_id, subcat_id, quantity, product_desc, pro_image)
                  VALUES ('$product_name', '$product_price', '$cat_id', '$subcat_id', '$quantity', '$product_desc', '$image_name')";

                if (mysqli_query($conn, $query)) {

                    $_SESSION['success'] = "Product added successfully!";
                    header('Location: ../add_product.php');
                    exit();
                } else {
                    echo "Error: " . $query . "<br>" . mysqli_error($conn);
                }
            } else {
                echo "Failed to upload image.";
            }
        }
    }
}

// ============================================================ update product ======================================================================


if (isset($_POST['update_product'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $cat_id = $_POST['cat_id'];
    $subcat_id = $_POST['subcat_id'];
    $quantity = $_POST['quantity'];
    $product_desc = $_POST['product_desc'];

    
    $pro_image = $_FILES['pro_image']['name'];
    $target_dir = "../uploads/";
    $target_file = $target_dir . basename($pro_image);

    if (!empty($pro_image)) {
      
        move_uploaded_file($_FILES['pro_image']['tmp_name'], $target_file);
        $update_query = "UPDATE products SET product_name='$product_name', product_price='$product_price', 
                         cat_id='$cat_id', subcat_id='$subcat_id', quantity='$quantity', 
                         product_desc='$product_desc', pro_image='$pro_image' WHERE id='$product_id'";
    } else {
        
        $update_query = "UPDATE products SET product_name='$product_name', product_price='$product_price', 
                         cat_id='$cat_id', subcat_id='$subcat_id', quantity='$quantity', 
                         product_desc='$product_desc' WHERE id='$product_id'";
    }

    if (mysqli_query($conn, $update_query)) {
        $_SESSION['success'] = "Product updated successfully!";
        
    } else {
        $_SESSION['error'] = "Failed to update product.";
    }

    header("Location: ../edit_product.php?pro_id=$product_id");

}

// ============================================================ delete product ===============================================================

if(isset($_GET['delete_pro_id'])){
   
       
            $delete_product = mysqli_query($conn, "DELETE FROM products WHERE id = '".$_GET['delete_pro_id']."'");
            if($delete_product){
                $_SESSION['success'] = "Product Delete successfully!";
                header('Location: ../product_list.php');

            }

}