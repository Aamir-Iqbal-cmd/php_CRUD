<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "php_crud_db";

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    echo "Error in database Connection";
}